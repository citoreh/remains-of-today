// Background service worker for "What Remains of Today".
// Keeps a live badge on the toolbar icon (e.g. "62%", "9h", or the nearest
// personal countdown), fires a notification when a personal alarm arrives,
// and refreshes once a minute plus whenever settings change.
"use strict";

const DEFAULT_STATE = { theme: 'amber', anchor: 'midnight', tz: 'local', badge: 'percent', weekStart: 'monday' };
const THEMES = { amber: '#ff9a5b', teal: '#34b3a0', violet: '#8a6bff', mono: '#aab6d4' };
const ALARM_NAME = 'wrt-tick';

function anchorSeconds(state){
  if (state.anchor === 'midnight' || state.anchor === '24:00') return 86400;
  const m = /^(\d{1,2}):(\d{2})$/.exec(state.anchor);
  if (!m) return 86400;
  let s = (+m[1]) * 3600 + (+m[2]) * 60;
  if (s <= 0 || s > 86400) s = 86400;
  return s;
}

function getWall(now, state){
  if (state.tz === 'local') return now;
  try{
    const fmt = new Intl.DateTimeFormat('en-US', { timeZone: state.tz, hourCycle: 'h23',
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const p = {}; for (const part of fmt.formatToParts(now)) p[part.type] = part.value;
    return new Date(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second, now.getMilliseconds());
  } catch(e){ return now; }
}

async function getState(){
  return new Promise(resolve => {
    chrome.storage.sync.get(DEFAULT_STATE, items => {
      if (chrome.runtime.lastError) { resolve({ ...DEFAULT_STATE }); return; }
      resolve(items);
    });
  });
}
async function getAlarms(){
  return new Promise(resolve => {
    chrome.storage.sync.get({ alarms: [] }, items => {
      if (chrome.runtime.lastError) { resolve([]); return; }
      resolve(Array.isArray(items.alarms) ? items.alarms : []);
    });
  });
}
function setAlarms(list){
  return new Promise(resolve => { chrome.storage.sync.set({ alarms: list }, resolve); });
}

async function fireDueNotifications(alarms){
  const now = Date.now();
  let changed = false;
  for (const a of alarms){
    const target = new Date(a.target).getTime();
    if (!a.notified && target <= now){
      a.notified = true;
      changed = true;
      try{
        chrome.notifications.create(`wrt-${a.id}`, {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: a.label || 'Countdown reached',
          message: 'This moment has arrived.',
          priority: 2
        });
      } catch(e){ /* notifications may be unavailable in some contexts */ }
    }
  }
  if (changed) await setAlarms(alarms);
  return alarms;
}

async function updateBadge(){
  const [state, alarmsRaw] = await Promise.all([getState(), getAlarms()]);
  const alarms = await fireDueNotifications(alarmsRaw);

  if (state.badge === 'off'){
    chrome.action.setBadgeText({ text: '' });
    return;
  }

  const now = new Date();
  const wall = getWall(now, state);
  const secIntoDay = wall.getHours() * 3600 + wall.getMinutes() * 60 + wall.getSeconds();
  const total = anchorSeconds(state);
  const secLeft = Math.max(0, total - secIntoDay);
  const frac = total > 0 ? secLeft / total : 0;
  const finalHour = secLeft > 0 && secLeft <= 3600;

  let text, color = finalHour ? '#ff4d4d' : (THEMES[state.theme] || THEMES.amber);

  if (state.badge === 'alarm'){
    const upcoming = alarms
      .filter(a => new Date(a.target).getTime() > Date.now())
      .sort((a, b) => new Date(a.target) - new Date(b.target))[0];
    if (upcoming){
      const daysLeft = Math.max(0, Math.ceil((new Date(upcoming.target).getTime() - Date.now()) / 86400000));
      text = `${daysLeft}d`;
      color = upcoming.color || color;
    } else {
      text = secLeft <= 0 ? '0%' : `${Math.round(frac * 100)}%`; // fall back to day % if no alarms
    }
  } else if (state.badge === 'hours'){
    const h = Math.ceil(secLeft / 3600);
    text = secLeft <= 0 ? '0h' : `${h}h`;
  } else {
    text = secLeft <= 0 ? '0%' : `${Math.round(frac * 100)}%`;
  }

  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
  try{ chrome.action.setBadgeTextColor({ color: '#0a0e1a' }); } catch(e){ /* older Chrome */ }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
  updateBadge();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
  updateBadge();
});
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === ALARM_NAME) updateBadge(); });
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'sync') updateBadge(); });

chrome.commands.onCommand.addListener(command => {
  if (command === 'open-full-page'){
    chrome.tabs.create({ url: chrome.runtime.getURL('fullpage.html') });
  }
});

chrome.notifications.onClicked.addListener(id => {
  if (id.startsWith('wrt-')) chrome.tabs.create({ url: chrome.runtime.getURL('fullpage.html') });
});

updateBadge();
