// Core "What Remains of Today" clock logic, shared by popup.html and fullpage.html.
// Reads/writes settings via chrome.storage.sync so the popup, full page, and
// toolbar badge (background.js) always agree.
(function (global) {
  "use strict";
  const DAY_MS = 86400000;
  const C  = 2 * Math.PI * 100;   // main ring circumference (r=100, viewBox 240)
  const CM = 2 * Math.PI * 34;    // mini ring circumference (r=34, viewBox 80)
  const $ = id => document.getElementById(id);

  const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const MO3 = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const WD = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const THEMES = { amber:'#ff9a5b', teal:'#34b3a0', violet:'#8a6bff', mono:'#aab6d4' };
  const RING_IDS = ['day','week','month','quarter','year'];
  const ALARM_COLORS = ['#ff6b6b','#ffb85b','#6be3a8','#5bc9ff','#c792ff','#ff8fc7'];
  const MAX_ALARMS = 8;

  const DEFAULT_STATE = {
    theme: 'amber', anchor: 'midnight', tz: 'local', badge: 'percent',
    weekStart: 'monday',
    hidden: { day:false, week:false, month:false, quarter:false, year:false }
  };
  const DEFAULT_ALARMS = [];

  function pad(n){ return String(n).padStart(2, '0'); }
  function uid(){ return 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }

  function anchorSeconds(state){
    if (state.anchor === 'midnight' || state.anchor === '24:00') return 86400;
    const m = /^(\d{1,2}):(\d{2})$/.exec(state.anchor);
    if (!m) return 86400;
    let s = (+m[1]) * 3600 + (+m[2]) * 60;
    if (s <= 0 || s > 86400) s = 86400;
    return s;
  }
  function anchorLabel(state){
    return (state.anchor === 'midnight' || state.anchor === '24:00') ? 'midnight' : state.anchor;
  }

  function getWall(now, state){
    if (state.tz === 'local') return now;
    try{
      const fmt = new Intl.DateTimeFormat('en-US', { timeZone: state.tz, hourCycle:'h23',
        year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit' });
      const p = {}; for (const part of fmt.formatToParts(now)) p[part.type] = part.value;
      return new Date(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second, now.getMilliseconds());
    } catch(e){ return now; }
  }

  // day-of-week offset from the configured week start (0 = start of week)
  function dowOffset(wall, weekStart){
    if (weekStart === 'saturday') return (wall.getDay() + 1) % 7; // Sat=0 ... Fri=6
    return (wall.getDay() + 6) % 7; // monday-start default: Mon=0 ... Sun=6
  }

  const anchors = [[0,[56,42,110]],[6,[196,104,96]],[12,[206,166,92]],[18,[198,108,64]],[24,[56,42,110]]];
  function skyTint(hf){
    let a = anchors[0], b = anchors[anchors.length - 1];
    for (let i = 0; i < anchors.length - 1; i++){ if (hf >= anchors[i][0] && hf <= anchors[i+1][0]){ a = anchors[i]; b = anchors[i+1]; break; } }
    const t = (hf - a[0]) / ((b[0] - a[0]) || 1);
    return a[1].map((v,i) => Math.round(v + (b[1][i] - v) * t));
  }
  const mix = (c1,c2,t) => c1.map((v,i) => Math.round(v + (c2[i] - v) * t));

  function storageGet(){
    return new Promise(resolve => {
      try{
        chrome.storage.sync.get(DEFAULT_STATE, items => {
          if (chrome.runtime.lastError) { resolve(structuredClone(DEFAULT_STATE)); return; }
          items.hidden = { ...DEFAULT_STATE.hidden, ...(items.hidden || {}) };
          resolve(items);
        });
      } catch(e){ resolve(structuredClone(DEFAULT_STATE)); }
    });
  }
  function storageSet(state){
    try{ chrome.storage.sync.set(state); } catch(e){}
  }
  function alarmsGet(){
    return new Promise(resolve => {
      try{
        chrome.storage.sync.get({ alarms: DEFAULT_ALARMS }, items => {
          if (chrome.runtime.lastError) { resolve([]); return; }
          resolve(Array.isArray(items.alarms) ? items.alarms : []);
        });
      } catch(e){ resolve([]); }
    });
  }
  function alarmsSet(list){
    try{ chrome.storage.sync.set({ alarms: list }); } catch(e){}
  }

  // format ms-left into a short, human string for a mini-ring number
  function shortLeft(msLeft){
    if (msLeft <= 0) return 'now';
    const mins = Math.ceil(msLeft / 60000);
    if (mins < 60) return `${mins}m`;
    const hrs = Math.ceil(msLeft / 3600000);
    if (hrs < 24) return `${hrs}h`;
    const days = Math.ceil(msLeft / DAY_MS);
    return `${days}d`;
  }
  function fmtWhen(iso){
    try{
      const d = new Date(iso);
      const opts = { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' };
      return d.toLocaleString(undefined, opts);
    } catch(e){ return iso; }
  }

  function RemainingClock(root, opts){
    opts = opts || {};
    const els = {
      arc: root.querySelector('#arc'), edge: root.querySelector('#edge'),
      th: root.querySelector('#th'), tm: root.querySelector('#tm'), ts: root.querySelector('#ts'),
      pct: root.querySelector('#pct'), until: root.querySelector('#until'),
      sky: root.querySelector('#sky'), dateline: root.querySelector('#dateline'),
      arcWeek: root.querySelector('#arcWeek'), numWeek: root.querySelector('#numWeek'), lblWeek: root.querySelector('#lblWeek'),
      arcMonth: root.querySelector('#arcMonth'), numMonth: root.querySelector('#numMonth'), lblMonth: root.querySelector('#lblMonth'),
      arcQuarter: root.querySelector('#arcQuarter'), numQuarter: root.querySelector('#numQuarter'), lblQuarter: root.querySelector('#lblQuarter'),
      arcYear: root.querySelector('#arcYear'), numYear: root.querySelector('#numYear'), lblYear: root.querySelector('#lblYear'),
      panel: root.querySelector('#panel'), gear: root.querySelector('#gear'),
      endChips: root.querySelector('#endChips'), endCustom: root.querySelector('#endCustom'),
      swatches: root.querySelector('#swatches'), tzSel: root.querySelector('#tzSel'),
      badgeChips: root.querySelector('#badgeChips'),
      weekStartChips: root.querySelector('#weekStartChips'),
      ringChips: root.querySelector('#ringChips'),
      alarmList: root.querySelector('#alarmList'),
      alarmLabel: root.querySelector('#alarmLabel'), alarmDate: root.querySelector('#alarmDate'),
      alarmColorRow: root.querySelector('#alarmColorRow'), alarmColorCustom: root.querySelector('#alarmColorCustom'),
      alarmAdd: root.querySelector('#alarmAdd'), alarmHint: root.querySelector('#alarmHint'),
      customRow: root.querySelector('#customRow')
    };

    [els.arc].forEach(a => { if (a) a.style.strokeDasharray = `${C} ${C}`; });
    [els.arcWeek, els.arcMonth, els.arcQuarter, els.arcYear].forEach(a => { if (a) a.style.strokeDasharray = `${CM} ${CM}`; });

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let state = structuredClone(DEFAULT_STATE);
    let alarms = [];
    let pickedColor = ALARM_COLORS[0];
    let lastSec = -1, lastTint = '', lastFinal = null;

    function ringEls(id){ return Array.from(root.querySelectorAll(`[data-ring="${id}"]`)); }

    function applyVisibility(){
      RING_IDS.forEach(id => {
        const on = !state.hidden[id];
        ringEls(id).forEach(el => { el.style.display = on ? '' : 'none'; });
      });
      if (els.ringChips) els.ringChips.querySelectorAll('[data-ringtoggle]').forEach(b => {
        b.classList.toggle('on', !state.hidden[b.dataset.ringtoggle]);
      });
    }

    function applyState(){
      document.body.dataset.theme = state.theme;
      if (els.endChips) els.endChips.querySelectorAll('[data-end]').forEach(b => b.classList.toggle('on', b.dataset.end === state.anchor));
      if (els.swatches) els.swatches.querySelectorAll('[data-theme]').forEach(b => b.classList.toggle('on', b.dataset.theme === state.theme));
      if (els.endCustom) els.endCustom.value = /^\d{1,2}:\d{2}$/.test(state.anchor) && state.anchor !== '24:00' ? state.anchor : '';
      if (els.tzSel) els.tzSel.value = state.tz;
      if (els.badgeChips) els.badgeChips.querySelectorAll('[data-badge]').forEach(b => b.classList.toggle('on', b.dataset.badge === state.badge));
      if (els.weekStartChips) els.weekStartChips.querySelectorAll('[data-weekstart]').forEach(b => b.classList.toggle('on', b.dataset.weekstart === state.weekStart));
      applyVisibility();
    }

    function setArc(el, frac, circ){ if (!el) return; el.style.strokeDashoffset = -((1 - Math.max(0, Math.min(1, frac))) * circ); }

    // ---------- personal alarm rings (built dynamically) ----------
    function miniRingSVG(color){
      return `<svg viewBox="0 0 80 80" aria-hidden="true">
        <circle cx="40" cy="40" r="34" fill="none" stroke="var(--track)" stroke-width="4"/>
        <circle class="alarmArc" cx="40" cy="40" r="34" fill="none" stroke="${color}" stroke-width="4"
                stroke-linecap="round" filter="url(#soft)" transform="rotate(-90 40 40)"
                style="stroke-dasharray:${CM} ${CM}"/>
      </svg>`;
    }

    function renderAlarmList(){
      if (!els.alarmList) return;
      if (alarms.length === 0){
        els.alarmList.innerHTML = `<p class="alarm-empty">No personal countdowns yet.</p>`;
        return;
      }
      els.alarmList.innerHTML = alarms.map(a => `
        <div class="alarm-row" data-id="${a.id}">
          <span class="alarm-dot" style="background:${a.color}"></span>
          <div class="alarm-meta">
            <span class="alarm-label">${escapeHtml(a.label || 'Untitled')}</span>
            <span class="alarm-when">${fmtWhen(a.target)}</span>
          </div>
          <button class="alarm-btn" data-act="toggle" title="${a.hidden ? 'Show circle' : 'Hide circle'}">
            ${a.hidden ? eyeOffSVG() : eyeSVG()}
          </button>
          <button class="alarm-btn" data-act="delete" title="Delete">${trashSVG()}</button>
        </div>`).join('');
    }
    function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
    function eyeSVG(){ return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg>`; }
    function eyeOffSVG(){ return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a21 21 0 0 1 5.06-6.06M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a21 21 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`; }
    function trashSVG(){ return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg>`; }

    function renderCustomRow(){
      if (!els.customRow) return;
      const visible = alarms.filter(a => !a.hidden);
      if (visible.length === 0){ els.customRow.innerHTML = ''; els.customRow.style.display = 'none'; return; }
      els.customRow.style.display = '';
      els.customRow.innerHTML = visible.map(a => `
        <aside class="mini alarm-mini" data-alarm-id="${a.id}">
          <div class="mini-dial">${miniRingSVG(a.color)}<div class="mini-num alarmNum">—</div></div>
          <div class="mini-label alarmLbl">${escapeHtml(a.label || 'Untitled')}</div>
        </aside>`).join('');
    }

    function tickAlarms(){
      if (!els.customRow) return;
      const nodes = els.customRow.querySelectorAll('.alarm-mini');
      const now = Date.now();
      nodes.forEach(node => {
        const id = node.dataset.alarmId;
        const a = alarms.find(x => x.id === id);
        if (!a) return;
        const target = new Date(a.target).getTime();
        const created = new Date(a.createdAt).getTime();
        const span = Math.max(1, target - created);
        const msLeft = target - now;
        const frac = Math.max(0, Math.min(1, msLeft / span));
        const arc = node.querySelector('.alarmArc');
        if (arc) setArc(arc, frac, CM);
        const numEl = node.querySelector('.alarmNum');
        if (numEl) numEl.textContent = shortLeft(msLeft);
      });
    }

    function openPanel(o){ if (els.panel) els.panel.classList.toggle('open', o); }

    function frame(){
      const now = new Date();
      const wall = getWall(now, state);

      const secIntoDay = wall.getHours() * 3600 + wall.getMinutes() * 60 + wall.getSeconds() + wall.getMilliseconds() / 1000;
      const total = anchorSeconds(state);
      const secLeft = Math.max(0, total - secIntoDay);
      const frac = total > 0 ? secLeft / total : 0;
      const elapsed = 1 - frac;

      setArc(els.arc, frac, C);
      if (els.edge){
        const ang = (-90 + elapsed * 360) * Math.PI / 180;
        els.edge.setAttribute('cx', 120 + 100 * Math.cos(ang));
        els.edge.setAttribute('cy', 120 + 100 * Math.sin(ang));
      }

      const finalHour = secLeft > 0 && secLeft <= 3600;
      if (finalHour !== lastFinal){ lastFinal = finalHour; document.body.classList.toggle('final-hour', finalHour); }

      const dow = dowOffset(wall, state.weekStart);
      const weekFrac = 1 - ((dow * 86400 + secIntoDay) / (7 * 86400));
      setArc(els.arcWeek, weekFrac, CM);
      const weekDays = Math.max(0, Math.ceil((7 * 86400 - (dow * 86400 + secIntoDay)) / 86400));

      const Y = wall.getFullYear(), M = wall.getMonth();
      const monthEnd = new Date(Y, M + 1, 1), dim = new Date(Y, M + 1, 0).getDate();
      const mMs = monthEnd - wall;
      setArc(els.arcMonth, mMs / (dim * DAY_MS), CM);

      const q = Math.floor(M / 3);
      const qStart = new Date(Y, q * 3, 1), qEnd = new Date(Y, q * 3 + 3, 1);
      const qMs = qEnd - wall;
      setArc(els.arcQuarter, qMs / (qEnd - qStart), CM);

      const yStart = new Date(Y, 0, 1), yEnd = new Date(Y + 1, 0, 1);
      const yMs = yEnd - wall;
      setArc(els.arcYear, yMs / (yEnd - yStart), CM);

      const whole = Math.floor(secLeft);
      if (whole !== lastSec){
        lastSec = whole;
        const h = Math.floor(whole / 3600), m = Math.floor((whole % 3600) / 60), s = whole % 60;
        if (els.th) els.th.textContent = pad(h);
        if (els.tm) els.tm.textContent = pad(m);
        if (els.ts) els.ts.textContent = pad(s);
        if (!reduce && els.ts){ els.ts.classList.remove('tick'); void els.ts.offsetWidth; els.ts.classList.add('tick'); }

        if (els.pct) els.pct.textContent = (frac * 100).toFixed(frac < .01 ? 2 : (frac < .1 ? 1 : 0)) + '%';
        if (els.until) els.until.textContent = secLeft <= 0 ? 'day complete' : 'until ' + anchorLabel(state);

        if (els.numWeek) els.numWeek.textContent = weekDays;
        if (els.numMonth) els.numMonth.textContent = Math.max(0, Math.ceil(mMs / DAY_MS));
        if (els.numQuarter) els.numQuarter.textContent = Math.max(0, Math.ceil(qMs / DAY_MS));
        if (els.numYear) els.numYear.textContent = Math.max(0, Math.ceil(yMs / DAY_MS));
        if (els.lblMonth) els.lblMonth.textContent = `days left in ${MONTHS[M]}`;
        if (els.lblQuarter) els.lblQuarter.textContent = `days left in Q${q + 1}`;
        if (els.lblYear) els.lblYear.textContent = `days left in ${Y}`;

        document.title = opts.setTitle === false ? document.title : `${pad(h)}:${pad(m)}:${pad(s)} · left today`;

        let dl = `${WD[wall.getDay()]} · ${wall.getDate()} ${MO3[M]} ${Y}`;
        if (state.tz !== 'local') dl += ` · ${state.tz.split('/').pop().replace('_', ' ')}`;
        if (els.dateline) els.dateline.textContent = dl;
      }

      tickAlarms();

      const hf = wall.getHours() + wall.getMinutes() / 60 + wall.getSeconds() / 3600;
      let tintArr = skyTint(hf);
      if (finalHour) tintArr = mix(tintArr, [255, 77, 77], 0.6);
      const tint = tintArr.join(',');
      if (tint !== lastTint && els.sky){
        lastTint = tint;
        els.sky.style.background = `radial-gradient(60% 55% at 50% 38%,rgba(${tint},${finalHour ? 0.26 : 0.18}) 0%, rgba(${tint},.06) 38%, transparent 70%)`;
      }
    }

    function addAlarm(){
      const label = (els.alarmLabel && els.alarmLabel.value || '').trim().slice(0, 40);
      const dateVal = els.alarmDate && els.alarmDate.value;
      if (els.alarmHint) els.alarmHint.textContent = '';
      if (!dateVal){ if (els.alarmHint) els.alarmHint.textContent = 'Pick a date and time first.'; return; }
      if (alarms.length >= MAX_ALARMS){ if (els.alarmHint) els.alarmHint.textContent = `Up to ${MAX_ALARMS} personal circles at a time.`; return; }
      const target = new Date(dateVal);
      if (isNaN(target.getTime())){ if (els.alarmHint) els.alarmHint.textContent = 'That date/time didn\u2019t parse — try again.'; return; }
      const alarm = {
        id: uid(), label: label || 'Untitled', target: target.toISOString(),
        color: pickedColor, createdAt: new Date().toISOString(), hidden: false, notified: false
      };
      alarms.push(alarm);
      alarmsSet(alarms);
      renderAlarmList(); renderCustomRow(); tickAlarms();
      if (els.alarmLabel) els.alarmLabel.value = '';
      if (els.alarmDate) els.alarmDate.value = '';
    }

    function wire(){
      if (els.gear){
        els.gear.addEventListener('click', () => openPanel(!els.panel.classList.contains('open')));
        els.gear.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' '){ e.preventDefault(); openPanel(!els.panel.classList.contains('open')); } });
      }
      document.addEventListener('click', e => {
        if (els.panel && els.gear && !els.panel.contains(e.target) && !els.gear.contains(e.target)) openPanel(false);
      });

      if (els.endChips) els.endChips.addEventListener('click', e => {
        const b = e.target.closest('[data-end]'); if (!b) return;
        state.anchor = b.dataset.end; storageSet(state); applyState(); lastSec = -1;
      });
      if (els.endCustom) els.endCustom.addEventListener('change', () => {
        if (/^\d{1,2}:\d{2}$/.test(els.endCustom.value)){ state.anchor = els.endCustom.value; storageSet(state); applyState(); lastSec = -1; }
      });
      if (els.swatches) els.swatches.addEventListener('click', e => {
        const b = e.target.closest('[data-theme]'); if (!b) return;
        state.theme = b.dataset.theme; storageSet(state); applyState(); lastSec = -1;
      });
      if (els.tzSel) els.tzSel.addEventListener('change', () => {
        const v = els.tzSel.value;
        if (v !== 'local'){ try{ new Intl.DateTimeFormat('en', { timeZone: v }); } catch(err){ return; } }
        state.tz = v; storageSet(state); applyState(); lastSec = -1;
      });
      if (els.badgeChips) els.badgeChips.addEventListener('click', e => {
        const b = e.target.closest('[data-badge]'); if (!b) return;
        state.badge = b.dataset.badge; storageSet(state); applyState();
      });
      if (els.weekStartChips) els.weekStartChips.addEventListener('click', e => {
        const b = e.target.closest('[data-weekstart]'); if (!b) return;
        state.weekStart = b.dataset.weekstart; storageSet(state); applyState(); lastSec = -1;
      });
      if (els.ringChips) els.ringChips.addEventListener('click', e => {
        const b = e.target.closest('[data-ringtoggle]'); if (!b) return;
        const id = b.dataset.ringtoggle;
        state.hidden = { ...state.hidden, [id]: !state.hidden[id] };
        storageSet(state); applyVisibility();
      });

      if (els.alarmColorRow){
        els.alarmColorRow.querySelectorAll('[data-color]').forEach(sw => {
          sw.addEventListener('click', () => {
            pickedColor = sw.dataset.color;
            els.alarmColorRow.querySelectorAll('[data-color]').forEach(s => s.classList.toggle('on', s === sw));
            if (els.alarmColorCustom) els.alarmColorCustom.value = pickedColor;
          });
        });
      }
      if (els.alarmColorCustom) els.alarmColorCustom.addEventListener('input', () => {
        pickedColor = els.alarmColorCustom.value;
        if (els.alarmColorRow) els.alarmColorRow.querySelectorAll('[data-color]').forEach(s => s.classList.remove('on'));
      });
      if (els.alarmAdd) els.alarmAdd.addEventListener('click', addAlarm);
      if (els.alarmDate) els.alarmDate.addEventListener('keydown', e => { if (e.key === 'Enter') addAlarm(); });
      if (els.alarmLabel) els.alarmLabel.addEventListener('keydown', e => { if (e.key === 'Enter') addAlarm(); });

      if (els.alarmList) els.alarmList.addEventListener('click', e => {
        const btn = e.target.closest('.alarm-btn'); if (!btn) return;
        const row = btn.closest('.alarm-row'); const id = row && row.dataset.id;
        const a = alarms.find(x => x.id === id); if (!a) return;
        if (btn.dataset.act === 'delete'){
          alarms = alarms.filter(x => x.id !== id);
        } else if (btn.dataset.act === 'toggle'){
          a.hidden = !a.hidden;
        }
        alarmsSet(alarms);
        renderAlarmList(); renderCustomRow(); tickAlarms();
      });

      document.addEventListener('keydown', e => {
        const k = e.key.toLowerCase();
        const typing = document.activeElement && ['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName);
        if (typing) return;
        if (opts.enableFullscreen !== false && k === 'f'){ toggleFull(); }
        else if (k === 's'){ openPanel(!els.panel.classList.contains('open')); }
        else if (e.key === 'Escape'){ openPanel(false); }
      });
    }

    let wl = null;
    async function reqWake(){ try{ if ('wakeLock' in navigator) wl = await navigator.wakeLock.request('screen'); } catch(e){} }
    function toggleFull(){
      if (!document.fullscreenElement){ (document.documentElement.requestFullscreen || (() => {})).call(document.documentElement); reqWake(); }
      else { (document.exitFullscreen || (() => {})).call(document); }
    }
    if (opts.enableFullscreen !== false){
      document.addEventListener('visibilitychange', () => { if (wl && document.visibilityState === 'visible') reqWake(); });
    }

    async function boot(){
      state = await storageGet();
      alarms = await alarmsGet();
      if (els.alarmColorRow){
        els.alarmColorRow.innerHTML = ALARM_COLORS.map((c,i) =>
          `<div class="asw${i === 0 ? ' on' : ''}" data-color="${c}" style="background:${c}" title="${c}"></div>`).join('');
        els.alarmColorRow.querySelectorAll('[data-color]').forEach(sw => {
          sw.addEventListener('click', () => {
            pickedColor = sw.dataset.color;
            els.alarmColorRow.querySelectorAll('[data-color]').forEach(s => s.classList.toggle('on', s === sw));
            if (els.alarmColorCustom) els.alarmColorCustom.value = pickedColor;
          });
        });
      }
      applyState();
      renderAlarmList();
      renderCustomRow();
      wire();
      if (reduce){ frame(); setInterval(frame, 1000); }
      else { (function loop(){ frame(); requestAnimationFrame(loop); })(); }

      // stay in sync if settings change elsewhere (e.g. popup vs full page open together)
      try{
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area !== 'sync') return;
          let changed = false;
          for (const k of Object.keys(DEFAULT_STATE)){
            if (changes[k]){ state[k] = changes[k].newValue; changed = true; }
          }
          if (changed){ applyState(); lastSec = -1; lastTint = ''; }
          if (changes.alarms){
            alarms = Array.isArray(changes.alarms.newValue) ? changes.alarms.newValue : [];
            renderAlarmList(); renderCustomRow(); tickAlarms();
          }
        });
      } catch(e){}
    }

    boot();
    return { toggleFull, openPanel };
  }

  global.WhatRemains = { RemainingClock, THEMES, DEFAULT_STATE, ALARM_COLORS };
})(window);
